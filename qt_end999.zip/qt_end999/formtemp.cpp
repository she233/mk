#include "formtemp.h"
#include "ui_formtemp.h"

extern QList<double> data_temp_1;
extern QList<double> data_temp_2;
extern QList<double> data_temp_3;

FormTemp::FormTemp(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormTemp)
{
    ui->setupUi(this);
    QChart *chart = new QChart();
    //3.创建坐标轴
    QValueAxis *valueX = new QValueAxis();
    QValueAxis *valueY = new QValueAxis();
    QTimer *chart_time = new QTimer();
    //设置坐标位置
    valueX->setRange(0,5000);
    valueY->setRange(1, 40);
    //设置坐标轴的标题和显示格式
    valueX->setTitleText("时间/ms");
    valueY->setTitleText("temp/ms");
    valueX->setLabelFormat("%d");
    valueY->setLabelFormat("%.1f");
    //图标添加坐标轴
    chart->createDefaultAxes();
    chart->addAxis(valueX, Qt::AlignBottom);
    chart->addAxis(valueY, Qt::AlignLeft);
    //设置标题
    chart->setTitle("温度时间曲线");

    //创建曲线对象添加
    line_1 = new QLineSeries();
    line_2 = new QLineSeries();
    line_3 = new QLineSeries();

    line_1->setName("节点1");
    line_2->setName("节点2");
    line_3->setName("节点3");

    QFont font = chart->legend()->font();
    font.setPointSizeF(14);
    chart->legend()->setFont(font);
    chart->setTitleFont(font);
    chart->legend()->setVisible(true);


    //图标添加曲线
    chart->addSeries(line_1);
    chart->addSeries(line_2);
    chart->addSeries(line_3);
    //将曲线的数据与坐标轴项链，注意，需要在图标添加曲线之后
    line_1->attachAxis(valueX);
    line_1->attachAxis(valueY);
    line_2->attachAxis(valueX);
    line_2->attachAxis(valueY);
    line_3->attachAxis(valueX);
    line_3->attachAxis(valueY);
    //把图标放置在图标视图
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    chart_time->start(200);
    connect(chart_time, SIGNAL(timeout()), this, SLOT(timerTimeOut()));
}

FormTemp::~FormTemp()
{
    delete ui;
}

void FormTemp::timerTimeOut()
{
    line_1->clear();
    line_2->clear();
    line_3->clear();
    int xSpace = 5000 / (51 - 1);
    for (int i = 0; i < data_temp_1.size(); ++i) {
        line_1->append(xSpace * i, data_temp_1.at(i));
        line_2->append(xSpace * i, data_temp_2.at(i));
        line_3->append(xSpace * i, data_temp_3.at(i));
    }
}
