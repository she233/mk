#include "formhislog.h"
#include "ui_formhislog.h"
#include <QFile>
#include <QFileDialog>

FormHisLog::FormHisLog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormHisLog)
{
    ui->setupUi(this);
    QByteArray array;
    QString filepath = QCoreApplication::applicationDirPath();
    QFile *file = new QFile(filepath + "/2.txt");
    file->open(QIODevice::ReadOnly);
    array = file->readAll();
    file->close();
    ui->textEdit->setText(QString(array));
}

FormHisLog::~FormHisLog()
{
    delete ui;
}

void FormHisLog::on_pushButton_clicked()
{
    QString filepath = QCoreApplication::applicationDirPath();
    QFile *file = new QFile(filepath + "/2.txt");
    file->open(QIODevice::WriteOnly);
    file->close();
    ui->textEdit->clear();
}
