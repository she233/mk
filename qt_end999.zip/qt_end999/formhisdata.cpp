#include "formhisdata.h"
#include "ui_formhisdata.h"
#include <QFile>
#include <QFileDialog>

FormHisData::FormHisData(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormHisData)
{
    ui->setupUi(this);
    QByteArray array;
    QString filepath = QCoreApplication::applicationDirPath();
    QFile *file = new QFile(filepath + "/1.txt");
    file->open(QIODevice::ReadOnly);
    array = file->readAll();
    file->close();
    ui->textEdit->setText(QString(array));
}

FormHisData::~FormHisData()
{
    delete ui;
}

void FormHisData::on_pushButton_clicked()
{
    QString filepath = QCoreApplication::applicationDirPath();
    QFile *file = new QFile(filepath + "/1.txt");
    file->open(QIODevice::WriteOnly);
    file->close();
    ui->textEdit->clear();
}
