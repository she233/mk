#ifndef FORMHISLOG_H
#define FORMHISLOG_H

#include <QWidget>

namespace Ui {
class FormHisLog;
}

class FormHisLog : public QWidget
{
    Q_OBJECT

public:
    explicit FormHisLog(QWidget *parent = nullptr);
    ~FormHisLog();

private slots:
    void on_pushButton_clicked();

private:
    Ui::FormHisLog *ui;
};

#endif // FORMHISLOG_H
